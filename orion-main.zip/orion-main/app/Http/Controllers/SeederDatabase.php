<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;

class SeederDatabase extends Controller
{
    protected $signature = "process:planetary-data";
    protected $description = "process planetary data from csv";
    protected $experimental_test = [];

    public function handle()
    /**
     * Run the database seeds.
     * Prepare it for collecting the baseline data for every celestial body
     */
    {
        $files = Storage::files('C:\Users\Tomy\PycharmProjects\Experiment - 7\Orbital mechanics calculations\Earth orbital mechanics results.csv');

        foreach ($files as $file) {
            if (str_ends_with($file, '.csv')) {
                // Open and read the CSV file
                $path = Storage::path($file);
                $handle = fopen($path, 'r');

                while (($data = fgetcsv($handle, 1000, ',')) !== false) {
                    $this->experimental_test[] = $data;
                }

                fclose($handle);
                
                // Optionally, delete or move the file after processing
            }
        }
        return $this->experimental_test;
    }
}
