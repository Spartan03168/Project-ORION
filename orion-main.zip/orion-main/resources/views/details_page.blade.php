<html>
    <head>
        <title>Expanded details of celestial bodies</title>
    </head>
    <?php

use PhpParser\Node\Expr\AssignOp\Div;
use App\Http\Controllers\SeederDatabase;
    $seeder = new SeederDatabase();
    $experimental_T1 = $seeder->handle();
    ?>
    
    <body>
        <h3>
            You are probably wondering what the point of this project is. The point of this project is to make a prototype of 
            a simaulation that tracks planets on their orbits using mathematically accurate calculations. The final product is 
            suppose to track it on their eliptical orbits by calculating their eccentricty real time.
        </h3>
        <h3>   
            List of planets:
            <!-- Place list of planets(Pluto is included) here -->
            <!-- Info will be stored on a database and be called in remotely -->
            <!-- Use tables in future -->
        </h3>
        <?php
        foreach ($experimental_T1 as $proportie => $value) {
            echo "<div> $proportie : $value  </div>";
        }
        ?>

        <h3>
            List of moons/natural satellites:
            <!-- PLace list of natural moons  as of last recorded -->
            <!-- Info will be stored on a database and be called in remotely -->
        </h3>
        <?php
        
        
        
        ?>
        <!-- foreach ($test_array_2 as $moon => $value) {
            echo "<div> $moon : $value  </div>";} -->
    </body>
</html>
