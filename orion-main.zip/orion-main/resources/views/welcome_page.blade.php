<!DOCTYPE html>
<html>
<head>
    <title>Welcome Page</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background-image: url('The_Little_Fox_and_the_Giant_Stars.jpg'); 
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .welcome-container {
            text-align: center;
            color: white; /* Adjust for better visibility depending on your image */
        }

        .welcome-message {
            font-size: 50px;
        }
    </style>
</head>
<body>

    <div class="welcome-container">
        <?php echo '<h1 class="welcome-message">Welcome</h1>'; ?>
        <!-- You can add more PHP code here -->
    </div>

</body>
</html>
