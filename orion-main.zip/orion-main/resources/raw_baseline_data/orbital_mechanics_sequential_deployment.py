import math

import numpy as np
import pandas as pd

"""
Add seeder database
Add database links
"""

def csv_generators(description_column, results_column, celestial_body):
    dataframe_desription = description_column
    assert(type(dataframe_desription) == list or type(dataframe_desription) == np.ndarray)
    dataframe_specifics = results_column
    assert (type(dataframe_specifics) == list or type(dataframe_specifics) == np.ndarray)
    dataframe_purpose = celestial_body
    assert (type(dataframe_purpose) == str)
    dataframe = pd.DataFrame()
    file_name = f"{dataframe_purpose.capitalize()} orbital mechanics results.csv"
    auto_download_automation_protocol = 1

    try:
        dataframe = pd.DataFrame({
            "Description": dataframe_desription,
            "Orbital mechanic result": dataframe_specifics
        })
    except:
        print("Double check the data or peramters. There was an error in the process of generating the csv file.")

    if auto_download_automation_protocol == 0:
        print(f"File name: {file_name}")
    elif auto_download_automation_protocol == 1:
        dataframe.to_csv(file_name, index=False)


def orbital_velocity(G, m1, r):
    G_constant = G
    object_1_mass = m1
    range_detected = r

    orbital_velocity = math.sqrt((G_constant*object_1_mass)/range_detected)
    return orbital_velocity

def keplers_third_law(G, mass_1, orbit_time):
    return_mode = 1
    g_constant = G
    assert(type(g_constant) == float or type(g_constant) == int)
    object_mass_1 = mass_1
    assert(type(object_mass_1) == int or type(object_mass_1) == float)
    orbital_time_period = orbit_time * 24 * 3600 #seconds conversion
    assert (type(orbital_time_period) == int or type(orbital_time_period) == float)

    ktl_formater = ((G * object_mass_1 * orbital_time_period**2) / (4 * math.pi**2))**(1/3)
    ktl_au_conversion = ktl_formater / (149.6e9)
    if return_mode == 0:
        print("---")
        print("|-Keplers third law-|")
        print(f"Keplers third law result: {ktl_formater}")
        print(f"keplers third law AU conversion: {ktl_au_conversion}")
        print("---")
    elif return_mode == 1:
        # Results are returned in astronomical units
        return ktl_au_conversion

def orbital_period(G,mass_1, mass_2,sm_axis):
    dev_mode = 0
    G_constant = G
    object_mass_1 = mass_1
    object_mass_2 = mass_2
    axis = sm_axis

    # Total mass
    total_mass = object_mass_1 + object_mass_2

    # Calculate the orbital period using the two-body problem formula
    pre_sqrt = (4 * math.pi ** 2 * axis ** 3) / (G_constant * total_mass)
    post_sqrt = math.sqrt(pre_sqrt)
    seconds_conversion = post_sqrt

    # Convert the period from seconds to days
    days_conversion = seconds_conversion / 86400

    if dev_mode == 1:
        print("---")
        print("|-Orbital period-|")
        print(f"Developer mode status: {dev_mode}")
        print(f"Pre square rooting: {pre_sqrt}")
        print(f"Post-square root: {post_sqrt}")
        print(f"Seconds conversion: {days_conversion}")
        print("---")
    else:
        return days_conversion

def newtons_law_of_gravitation(G, mass_1, mass_2, distance, dev_mode):
    return_mode = 1
    if dev_mode == 1 and return_mode == 0:
        print("Newtons law of gravitation developer mode active")

    G_constant = G
    assert(type(G_constant) == float)
    object_1_mass = mass_1
    assert(type(object_1_mass) == float)
    object_2_mass = mass_2
    assert(type(object_2_mass) == float)
    distance_between_obj = distance

    gravitaional_force_strength = G_constant * ((object_1_mass * object_2_mass) / (distance_between_obj ** 2))
    if gravitaional_force_strength < 0:
        if return_mode == -1:
            print(-1)
        elif return_mode == 1:
            return -1
    elif gravitaional_force_strength > 0:
        if return_mode == -1:
            print(f"Gravitational force: {gravitaional_force_strength}")
        elif return_mode == 1:
            return gravitaional_force_strength

celestial_body = input("Celestial body: ")
gravitational_constant = 6.67430e-11
m1 = float(input("Mass of first object: "))
m2 = float(input("Mass of second object: "))
range_calculations_ktl = range_calc = float(input("Range between objects: "))
orbit_period = orbital_period(G=gravitational_constant, mass_1=m1, mass_2=m2,
                              sm_axis=range_calculations_ktl)  # earth orbit time
keplers_third_law_calc = keplers_third_law(gravitational_constant, m1, orbit_period)  # distance from sun

gravitaional_influence = newtons_law_of_gravitation(gravitational_constant, m1, m2,
                                                    keplers_third_law_calc, 0)  # gravitational influence

orbital_speed = orbital_velocity(gravitational_constant, m1, keplers_third_law_calc)  # orbital speed
orbit_distance = 2 * math.pi * keplers_third_law_calc # Orbit distance

orbital_mechanics_details = ["Gravitaional influence from star(Newtons)", "Orbital period(days)",
                             "Keplers third law(AU)", "Orbital velocity(km/s)", "Orbit distance(AU)",
                             "Object mass(kg)", "Distance covered per second(AU/s)"]
orbital_mechanics_results = [gravitaional_influence, orbit_period, keplers_third_law_calc, orbital_speed,
                             orbit_distance, m2, (orbit_distance) / (orbit_period * 86400)]
csv_generators(orbital_mechanics_details, orbital_mechanics_results, celestial_body)


